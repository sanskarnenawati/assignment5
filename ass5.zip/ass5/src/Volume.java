// Interface Volume
public interface Volume {
    double calculateVolume();
}